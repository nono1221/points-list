from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
import socket
import json
import hashlib
import os

app = Flask(__name__, static_folder='web', static_url_path='')
CORS(app)  # Enable CORS
app.secret_key = os.urandom(24)  # Generate random secret key for session

# Load password config
with open('key.json', 'r') as f:
    key_config = json.load(f)

# Load locales
with open('locales.json', 'r', encoding='utf-8') as f:
    locales = json.load(f)

def load_page_config():
    """Load page configuration"""
    with open('config.json', 'r', encoding='utf-8') as f:
        return json.load(f)

def get_locale(lang=None):
    """Get locale strings for the specified language"""
    if lang is None:
        lang = session.get('language', 'en')
    return locales.get(lang, locales['en'])

def verify_password(password):
    """Verify password using SHA-256 hash comparison"""
    hashed = hashlib.sha256(password.encode()).hexdigest()
    return hashed == key_config['hashed_password']

def require_api_key(f):
    """API key verification decorator for protecting data modification APIs"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Get API key from request header or body
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            data = request.get_json(silent=True) or {}
            api_key = data.get('api_key')
        
        if not api_key:
            return jsonify({"error": "Missing API key"}), 401
        
        if not verify_password(api_key):
            return jsonify({"error": "Invalid API key"}), 403
        
        return f(*args, **kwargs)
    return decorated_function

# Data file path
DATA_FILE = 'students_data.json'

# Default student data
DEFAULT_STUDENTS = [
    {"id": 1, "name": "name", "score": 12}
]

def load_students():
    """Load student data from file"""
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"Loaded {len(data)} students data")
                return data
        except Exception as e:
            print(f"Failed to load data: {e}, using default data")
            return DEFAULT_STUDENTS.copy()
    else:
        print("Data file does not exist, using default data")
        return DEFAULT_STUDENTS.copy()

def save_students():
    """Save student data to file"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(students, f, ensure_ascii=False, indent=2)
        print(f"Data saved: {len(students)} students")
    except Exception as e:
        print(f"Failed to save data: {e}")

# Student data storage
students = load_students()

# Helper function: generate new ID
def generate_new_id():
    if not students:
        return 1
    return max(student["id"] for student in students) + 1

# Helper function: get red card students
def get_red_card_students():
    return [student for student in students if student["score"] <= 0]

# API routes

@app.route('/api/students', methods=['GET'])
def get_students():
    """Get all students"""
    return jsonify(students)

@app.route('/api/students', methods=['POST'])
@require_api_key
def add_student():
    """Add new student"""
    data = request.json
    if not data or 'name' not in data:
        return jsonify({"error": "Missing student name"}), 400
    
    # Check if student with same name already exists
    if any(student["name"] == data["name"] for student in students):
        return jsonify({"error": "Student with this name already exists"}), 400
    
    new_student = {
        "id": generate_new_id(),
        "name": data["name"],
        "score": 12
    }
    students.append(new_student)
    save_students()  # Save data
    return jsonify(new_student), 201

@app.route('/api/students/<int:student_id>/score', methods=['POST'])
@require_api_key
def update_score(student_id):
    """Update student score"""
    data = request.json
    if not data or 'points' not in data:
        return jsonify({"error": "Missing score change value"}), 400
    
    student = next((s for s in students if s["id"] == student_id), None)
    if not student:
        return jsonify({"error": "Student not found"}), 404
    
    # Update score
    student["score"] += data["points"]
    
    # Ensure score is within valid range
    if student["score"] < 0:
        student["score"] = 0
    elif student["score"] > 18:
        student["score"] = 18
    
    save_students()  # Save data
    return jsonify(student)

@app.route('/api/students/<int:student_id>/reset', methods=['POST'])
@require_api_key
def reset_student_score(student_id):
    """Reset single student score"""
    student = next((s for s in students if s["id"] == student_id), None)
    if not student:
        return jsonify({"error": "Student not found"}), 404
    
    student["score"] = 12
    save_students()  # Save data
    return jsonify(student)

@app.route('/api/students/reset-all', methods=['POST'])
@require_api_key
def reset_all_scores():
    """Reset all student scores"""
    for student in students:
        student["score"] = 12
    save_students()  # Save data
    return jsonify({"message": "All scores have been reset"})

@app.route('/api/students/<int:student_id>', methods=['DELETE'])
@require_api_key
def delete_student(student_id):
    """Delete student"""
    global students
    students = [student for student in students if student["id"] != student_id]
    save_students()  # Save data
    return jsonify({"message": "Student deleted"})

@app.route('/api/red-cards', methods=['GET'])
def get_red_cards():
    """Get red card students"""
    return jsonify(get_red_card_students())

# Home route
@app.route('/')
def index():
    # Check if language has been set
    if session.get('language', None) is None:
        return app.send_static_file('language.html')
    # Check if user has accepted the agreement
    if not session.get('agreement_accepted', False):
        return app.send_static_file('agreement.html')
    return app.send_static_file('display.html')

@app.route('/admin')
def admin():
    """Admin page, requires authentication"""
    if 'authenticated' in session and session['authenticated']:
        return send_from_directory('web', 'admin.html')
    return jsonify({"error": "Please login first"}), 401

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    """Admin login verification"""
    data = request.json
    if not data or 'password' not in data:
        return jsonify({"error": "Missing password"}), 400
    
    if verify_password(data['password']):
        session['authenticated'] = True
        return jsonify({"message": "Login successful"})
    return jsonify({"error": "Incorrect password"}), 401

@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    """Admin logout"""
    session.pop('authenticated', None)
    return jsonify({"message": "Logout successful"})

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get page configuration"""
    return jsonify(load_page_config())

@app.route('/api/agreement/status', methods=['GET'])
def get_agreement_status():
    """Check if user has accepted the agreement"""
    accepted = session.get('agreement_accepted', False)
    return jsonify({"accepted": accepted})

@app.route('/api/agreement/accept', methods=['POST'])
def accept_agreement():
    """Mark agreement as accepted"""
    session['agreement_accepted'] = True
    return jsonify({"message": "Agreement accepted"})

@app.route('/api/language', methods=['GET'])
def get_language():
    """Get current language setting"""
    lang = session.get('language', None)
    if lang is None:
        # Auto-detect from browser
        lang = request.accept_languages.best_match(['zh', 'en'], default='en')
        session['language'] = lang
    return jsonify({"language": lang, "locale": get_locale(lang)})

@app.route('/api/language', methods=['POST'])
def set_language():
    """Set language preference"""
    data = request.json
    if not data or 'language' not in data:
        return jsonify({"error": "Missing language parameter"}), 400
    
    lang = data['language']
    if lang not in locales:
        return jsonify({"error": "Invalid language"}), 400
    
    session['language'] = lang
    return jsonify({"message": "Language updated", "language": lang, "locale": get_locale(lang)})

@app.route('/api/language/status', methods=['GET'])
def get_language_status():
    """Check if language has been set"""
    lang = session.get('language', None)
    return jsonify({"set": lang is not None, "language": lang})

# Auto get local IP address

def get_local_ip():
    try:
        # Create socket connection to external server to get local IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception as e:
        print(f"Failed to get local IP: {e}")
        return '0.0.0.0'  # Use 0.0.0.0 if failed

if __name__ == '__main__':
    local_ip = get_local_ip()
    port = 80
    print(f"Server started at http://{local_ip}:{port}")
    app.run(debug=True, host=local_ip, port=port)
