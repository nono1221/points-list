#!/usr/bin/env python3
"""
Password modification tool
Used to modify the administrator password for the points system
"""

import json
import hashlib
import os

# Get current directory
base_dir = os.path.dirname(os.path.abspath(__file__))
key_file = os.path.join(base_dir, 'key.json')

print("=== Points System Password Modification Tool ===")
print("\nPlease enter new administrator password:")
password = input().strip()

if not password:
    print("\nError: Password cannot be empty!")
    exit(1)

# Confirm password
print("\nPlease enter the new password again:")
confirm_password = input().strip()

if password != confirm_password:
    print("\nError: The two passwords do not match!")
    exit(1)

# Generate SHA-256 hash
hashed_password = hashlib.sha256(password.encode()).hexdigest()

# Read current configuration
config = {}
if os.path.exists(key_file):
    with open(key_file, 'r', encoding='utf-8') as f:
        config = json.load(f)

# Update password hash
config['hashed_password'] = hashed_password

# Save configuration
with open(key_file, 'w', encoding='utf-8') as f:
    json.dump(config, f, ensure_ascii=False, indent=4)

print(f"\n✅ Password modified successfully!")
print(f"New password: {password}")
print(f"Password hash: {hashed_password}")
print(f"\nConfiguration file updated: {key_file}")
print("\nPlease restart the server for the new password to take effect.")
